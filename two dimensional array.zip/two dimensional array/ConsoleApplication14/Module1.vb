﻿Module Module1

    Sub Main()
        Dim s(4, 4), n, a As String

        For r = 0 To 3
            Console.WriteLine("enter name and score")
            For c = 0 To 3
                If c <> 3 Then
                    s(r, c) = Console.ReadLine()
                Else
                    Int.parse(s(r,1)
                    s(r, 3) = (s(r, 1) + s(r, 2)) / 2
                End If
            Next

        Next
        Console.WriteLine("students name" & vbTab & "quiz 1" & vbTab & "quiz 2" & vbTab & "average")
        Console.WriteLine("------------------------------------------------")
        For r = 0 To 3

            For c = 0 To 3

                Console.Write(s(r, c) & vbTab)


            Next
            Console.WriteLine()

        Next
        Console.WriteLine("enter name to search")
        n = Console.ReadLine()
        For r = 0 To 3
            If s(r, 0) = n Then
                Console.WriteLine(s(r, 0) & vbTab & s(r, 1) & vbTab & s(r, 2))
            End If
        Next
    End Sub

End Module
