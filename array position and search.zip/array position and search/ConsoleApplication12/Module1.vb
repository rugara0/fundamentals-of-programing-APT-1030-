﻿Module Module1

    Sub Main()
        Dim c(10), i, t, s, m As Integer
        t = 0
        Console.WriteLine("enter 10 values for the array")
        For i = 0 To 9
            c(i) = Console.ReadLine()
            t = t + c(i)
        Next
        Console.WriteLine("display array")

        For i = 0 To 9
            Console.WriteLine("array" & i & "is" & c(i))

        Next
        Console.WriteLine("total sum  is:" & t)
        Console.WriteLine("enter no to search")
        s = Console.ReadLine()
        For i = 0 To 9
            If c(i) = s Then
                s = s + 1
                Console.WriteLine("number at position at position" & i)
                m = 1

            End If
            

        Next
         Console.WriteLine("number found" & s"times")
        If m = 0 Then
            Console.WriteLine("not found")
        End If
    End Sub
    'two arrays that key in data and then program tell you if both array have same data even when interchanged(compare arrays n if equal or not)
End Module
